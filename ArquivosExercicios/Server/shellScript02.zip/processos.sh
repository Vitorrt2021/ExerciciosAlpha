#!/bin/bash



echo "Os processos com esse parâmetro são; "
echo " "


ps | grep $1


