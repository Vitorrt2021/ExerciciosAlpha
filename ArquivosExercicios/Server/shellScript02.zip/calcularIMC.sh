#!/bin/bash

echo -n "Escreva sua altura (M): "
read altura;

while ! [[ ($altura =~ ^[0-9]*\.[0-9]+$ || $altura =~ ^[0-9]+$) ]]
do
	echo -n "Erro: adiciona um número em (M): "
	read altura
done

echo -n "Escreva seu peso em (Kg): "
read peso;



while ! [[( $peso =~ ^[0-9]*\.[0-9]+$ || $peso =~ ^[0-9]+$) ]]
do
	echo -n "Erro: adicione um número em (Kg): "
	read peso
done

imc=$(echo "scale=2;$peso / ($altura * $altura)" | bc -l)

if [ 1 -eq "$(echo "$imc < 18.5" | bc)" ]
then 
	estado="Magreza"

elif [ 1 -eq "$(echo "$imc < 24.9" | bc)" ]
then 
	estado="Saudável"

elif [ 1 -eq "$(echo "$imc < 29.9" | bc)" ]
then 
	estado="Sobrepeso"

elif [ 1 -eq "$(echo "$imc < 34.9" | bc)" ]
then 
	estado="Obesidade Grau I"

elif [ 1 -eq "$(echo "$imc < 39.9" | bc)" ]
then 
	estado="Obesidade Grau II (severa)"

else 
	estado="Obesidade Grau III (morbida)"
fi
echo "O seu IMC é igual a $imc então sua classificação é de $estado"

